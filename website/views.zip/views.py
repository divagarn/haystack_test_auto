from django.shortcuts import render, redirect, HttpResponse
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages 
import subprocess, os, rospy, threading
from .models import DisinfectionRun


# import subprocess
# import os
# import rospy
# import threading
# from django.shortcuts import render, HttpResponse
# from .models import DisinfectionRun


def change_mode_to_disinfect():
    # rospy.set_param('/disinfect_room_number', int(12))
    rospy.set_param('/haystack/mode', 'DISINFECT')

def change_mode_to_idle():
    rospy.set_param('/haystack/mode', 'IDLE')

def run_ros_node():
    rospy.init_node('disinfection_node', anonymous=True)
    rospy.spin()

def run_dis(request):

    # Get the ROS_MASTER_URI from the form submission
    ros_master_uri = request.POST.get('ros_master_uri', 'http://default-ros-master-uri:11311')
    os.environ['ROS_MASTER_URI'] = ros_master_uri
    os.environ['ROS_IP'] = '172.16.2.66'
    # # Set the environment variables for the Django project
    # os.environ['ROS_MASTER_URI'] = 'http://172.16.2.79:11311'
    # os.environ['ROS_IP'] = '172.16.2.66'

    # Start the ROS node in a separate thread
    ros_thread = threading.Thread(target=run_ros_node)
    ros_thread.start()

    if request.method == 'POST':
        try:
            # room_number= int(request.POST.get('room_number', 0))
            input_number = int(request.POST.get('number'))
            # room_setup = int(request.POST.get('room_setup', 0))

            # Validate the room number and room setup number
            # if room_number <= 0 or room_setup <= 0:
            # if room_number <= 0:
            #     return HttpResponse("Error: Invalid room number or room setup number.")
            
            # rospy.set_param('/room_setup_number', room_setup)
            
            num_runs = int(request.POST.get('num_runs', 0))
            if num_runs <= 0 :
                return HttpResponse("Error: Invalid number of runs.")

            run = 0 
            
            while run < num_runs + 1:
                mode = rospy.get_param('/haystack/mode', default='IDLE')
                if mode == 'IDLE':
                    
                    
                    
                    rospy.loginfo("Mode is IDLE. Waiting for 10 seconds...")
                    rospy.sleep(10)
                    # rospy.set_param('/disinfect_room_number', room_number + 1)
                    rospy.set_param('/disinfect_room_number', input_number)
                    change_mode_to_disinfect()
                    rospy.loginfo("Mode changed to DISINFECT.")
                    # Save data into the MySQL database after each iteration
                    # DisinfectionRun.objects.create(
                    #     room_number=room_number,
                    #     room_setup=room_setup,
                    #     run_count=run,
                    #     master_ip=ros_master_uri,
                    # )
                    # # Append data for the current run to the list
                    # run_data.append({
                    #     'room_number': room_number,
                    #     'room_setup': room_setup,
                    #     'run_count': run,
                    #     'master_ip': ros_master_uri,
                    #     'created_at': timezone.now(),  # Import timezone if needed: from django.utils import timezone
                    # })
                    # room_number +=1
                    run += 1
                    input_number +=1
                    # room_number +=1
                    return HttpResponse(f"The value of 'a' is: {input_number}")
                else:
                    rospy.loginfo("Mode is not IDLE. Waiting for 5 seconds...")
                    rospy.sleep(5)

            change_mode_to_idle()
            rospy.loginfo("All runs completed. Mode changed back to IDLE.")

            return HttpResponse("All runs completed successfully.")
            return redirect('home')
        except Exception as e:
            return HttpResponse(f"Error: {e}")
    else:
        # Fetch all previous disinfection runs from the database
        previous_runs = DisinfectionRun.objects.all()

        # return render(request, 'rosui/run_dis.html', {'runs': previous_runs, 'room_number_entered': room_number})

        return render(request, 'home.html', {})


def home(request):
    #check if logging in or not
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        #auth
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, "welcome to haystack!")
            # Get the ROS_MASTER_URI from the form submission
            return redirect('home')
        else: 
            messages.success(request, "there was an error logging in, please try again latter...!")
            return redirect('home')
    else:

        return render(request, 'home.html', {})
    


def logout_user(request):
    logout(request)
    messages.success(request, "Sucessfully loged out...")
    return redirect('home')


